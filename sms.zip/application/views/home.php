<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!--HEADER-->
<?php
	$this->load->view('nav'); 
?>
<!--HEADER END-->




<div class="container">
   <div class="row">
   	  
	</div>
</div>





<!--FOOTER-->
<?php
	$this->load->view('foot'); 
?>
<!--FOOTER END-->

